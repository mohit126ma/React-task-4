import { useState } from "react";
import "./App.css";

const PALETTES = [
  { name: "Indigo", primary: "#6366f1", glow: "rgba(99, 102, 241, 0.35)" },
  { name: "Emerald", primary: "#10b981", glow: "rgba(16, 185, 129, 0.35)" },
  { name: "Rose", primary: "#f43f5e", glow: "rgba(244, 63, 94, 0.35)" },
  { name: "Amber", primary: "#f59e0b", glow: "rgba(245, 158, 11, 0.35)" },
];

export default function App() {
  const [count, setCount] = useState(0);
  const [step, setStep] = useState(1);
  const [darkMode, setDarkMode] = useState(false);
  const [palette, setPalette] = useState(PALETTES[0]);

  // Statistics
  const [history, setHistory] = useState([]);
  const [stats, setStats] = useState({
    totalClicks: 0,
    max: 0,
    min: 0,
  });

  const recordAction = (newVal, type) => {
    const time = new Date().toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });

    setHistory((prev) => [{ val: newVal, type, time }, ...prev.slice(0, 5)]);

    setStats((prev) => ({
      totalClicks: prev.totalClicks + 1,
      max: Math.max(prev.max, newVal),
      min: Math.min(prev.min, newVal),
    }));
  };

  const updateCount = (delta) => {
    setCount((prev) => {
      const next = prev + delta;
      recordAction(next, delta > 0 ? `+${delta}` : `${delta}`);
      return next;
    });
  };

  const handleReset = () => {
    setCount(0);
    recordAction(0, "Reset");
  };

  return (
    <div
      className={`app ${darkMode ? "dark-theme" : "light-theme"}`}
      style={{
        "--accent": palette.primary,
        "--accent-glow": palette.glow,
      }}
    >
      {/* Header */}
      <header className="header">
        <div className="brand">
          <div className="brand-badge">React Hooks</div>
          <h1>State Playground</h1>
          <p>Interactive counter, theme engine, and state history.</p>
        </div>

        <div className="header-actions">
          {/* Palette Picker */}
          <div className="palette-picker" title="Pick Accent Theme">
            {PALETTES.map((p) => (
              <button
                key={p.name}
                aria-label={p.name}
                className={`palette-dot ${palette.name === p.name ? "active" : ""}`}
                style={{ backgroundColor: p.primary }}
                onClick={() => setPalette(p)}
              />
            ))}
          </div>

          {/* Theme Toggle */}
          <button
            className="theme-toggle"
            onClick={() => setDarkMode(!darkMode)}
          >
            {darkMode ? "☀️ Light" : "🌙 Dark"}
          </button>
        </div>
      </header>

      {/* Main Grid */}
      <main className="main-content">
        {/* Card 1: Counter Core */}
        <section className="card counter-card">
          <div className="card-header">
            <span className="card-icon">⚡</span>
            <div>
              <h2>Counter Station</h2>
              <p className="card-description">
                Configurable step sizes and fluid counter logic.
              </p>
            </div>
          </div>

          {/* Display */}
          <div className="counter-display">
            <span className="count-number">{count}</span>
            <span className="count-sub">Current Value</span>
          </div>

          {/* Step Selector */}
          <div className="step-selector">
            <span>Step Size:</span>
            {[1, 5, 10].map((s) => (
              <button
                key={s}
                className={`step-btn ${step === s ? "active" : ""}`}
                onClick={() => setStep(s)}
              >
                ±{s}
              </button>
            ))}
          </div>

          {/* Buttons */}
          <div className="counter-buttons">
            <button
              className="counter-btn decrement"
              onClick={() => updateCount(-step)}
            >
              − {step}
            </button>
            <button className="counter-btn reset" onClick={handleReset}>
              ↻ Reset
            </button>
            <button
              className="counter-btn increment"
              onClick={() => updateCount(step)}
            >
              + {step}
            </button>
          </div>
        </section>

        {/* Card 2: Analytics & Stats */}
        <section className="card stats-card">
          <div className="card-header">
            <span className="card-icon">📊</span>
            <div>
              <h2>Session Analytics</h2>
              <p className="card-description">
                Real-time derivation of your session activity.
              </p>
            </div>
          </div>

          <div className="stats-grid">
            <div className="stat-box">
              <span className="stat-label">Total Clicks</span>
              <strong className="stat-value">{stats.totalClicks}</strong>
            </div>
            <div className="stat-box">
              <span className="stat-label">Highest Value</span>
              <strong className="stat-value">{stats.max}</strong>
            </div>
            <div className="stat-box">
              <span className="stat-label">Lowest Value</span>
              <strong className="stat-value">{stats.min}</strong>
            </div>
          </div>

          <div className="history-section">
            <h3>Recent Changes</h3>
            {history.length === 0 ? (
              <p className="empty-history">No operations logged yet.</p>
            ) : (
              <ul className="history-list">
                {history.map((item, idx) => (
                  <li key={idx} className="history-item">
                    <span className="history-badge">{item.type}</span>
                    <span className="history-result">Result: {item.val}</span>
                    <span className="history-time">{item.time}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="footer">
        <p>Built with React & Vite • Demonstrating UI states & dynamic styling</p>
      </footer>
    </div>
  );
}