import React, { useState } from "react";
import "./Counter.css";

function Counter() {
  const [count, setCount] = useState(0);

  const increment = () => {
    setCount((previousCount) => previousCount + 1);
  };

  const decrement = () => {
    setCount((previousCount) => previousCount - 1);
  };

  const reset = () => {
    setCount(0);
  };

  return (
    <section className="counter-card">
      <div className="counter-icon">🔢</div>

      <h2>Counter</h2>

      <p className="counter-description">
        Use the buttons below to increase, decrease, or reset the counter.
      </p>

      <div className="count-display">{count}</div>

      <div className="counter-buttons">
        <button className="counter-button decrement-button" onClick={decrement}>
          <span>−</span>
          Decrement
        </button>

        <button className="counter-button reset-button" onClick={reset}>
          <span>↻</span>
          Reset
        </button>

        <button className="counter-button increment-button" onClick={increment}>
          <span>+</span>
          Increment
        </button>
      </div>
    </section>
  );
}

export default Counter;
