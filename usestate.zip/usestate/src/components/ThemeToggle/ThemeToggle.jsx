import React from "react";
import "./ThemeToggle.css";

function ThemeToggle({ darkMode, onToggle }) {
  return (
    <section className="theme-card">
      <div className="theme-icon">{darkMode ? "🌙" : "☀️"}</div>

      <h2>Theme Toggle</h2>

      <p className="theme-description">
        Switch between Light Theme and Dark Theme using boolean state.
      </p>

      <div className="current-theme-box">
        <span className="theme-label">Current Theme</span>

        <strong>{darkMode ? "Dark Theme" : "Light Theme"}</strong>
      </div>

      <button className="theme-action-button" onClick={onToggle}>
        {darkMode ? "☀️ Switch to Light Theme" : "🌙 Switch to Dark Theme"}
      </button>
    </section>
  );
}

export default ThemeToggle;
